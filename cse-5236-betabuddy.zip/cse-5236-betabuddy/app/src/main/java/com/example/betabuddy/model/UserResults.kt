package com.example.betabuddy.model

data class UserResults(
    val uid: String = "",
    val name: String = "",
    val skillLevel: String = "",
    val location: String = ""
)
